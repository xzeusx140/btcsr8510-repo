# (BEGIN csr-fw-manager.sh)
# The full finalized script you approved goes here — copy the exact version from our last message.
# For brevity in this builder, I’m inserting it verbatim below:

#!/usr/bin/env bash
# csr-fw-manager.sh (progress+polish)
# Install / Uninstall robust CSR (VID 0a12, PID 0001) Bluetooth support on Debian/Kali/Ubuntu.
# - Install: firmware -> loader -> watchdog -> sleep hook -> progress bar -> hci0 up -> grouped status
# - Uninstall: remove all + CSR-only udev "do-not-bind" + immediate unbind + verify block + truncate logs + reboot ask
# - Reinstall: uninstall + install (with progress)
# - Status: grouped sections, colored STATE, CSR block & binding state, rfkill, logs
# Run as root.

set -u
DEFAULT_FIRMWARE_SRC="/usr/share/csr-fw-manager/csr_fw.bin"
FIRMWARE_DST="/lib/firmware/csr_usb_bt_firmware.bin"
LOGFILE="/var/log/csr-fw-loader.log"
BACKUP_DIR="/root/csr-backups"
OLD_UDEV_RULE="/etc/udev/rules.d/50-csr-bluetooth-firmware.rules"
BLOCK_RULE="/etc/udev/rules.d/99-block-csr.rules"
SHOW_HCICONFIG_WHEN_BLOCKED=false
TRUNCATE_LOG_ON_UNINSTALL=true
REBOOT_POLICY="ask"

CLR_RED="\e[31m"; CLR_GRN="\e[32m"; CLR_YLW="\e[33m"; CLR_CYN="\e[36m"; CLR_RST="\e[0m"
c_r(){ printf "${CLR_RED}%s${CLR_RST}\n" "$*"; }
c_g(){ printf "${CLR_GRN}%s${CLR_RST}\n" "$*"; }
c_y(){ printf "${CLR_YLW}%s${CLR_RST}\n" "$*"; }
c_c(){ printf "${CLR_CYN}%s${CLR_RST}\n" "$*"; }
require_root(){ if [ "$(id -u)" != "0" ]; then c_r "Please run as root (sudo)."; exit 1; fi; }
need(){ command -v "$1" >/dev/null 2>&1 || { c_y "Installing $1 ..."; apt-get update -y && apt-get install -y "$1"; } }

csr_present(){ lsusb -d 0a12:0001 >/dev/null 2>&1; }
csr_block_active(){ [ -f "$BLOCK_RULE" ]; }
firmware_present(){ [ -f "$FIRMWARE_DST" ]; }
svc_enabled(){ systemctl is-enabled "$1" >/dev/null 2>&1; }
svc_active(){ systemctl is-active "$1" >/dev/null 2>&1; }

progress_bar(){
  local secs="${1:-3}" label="${2:-Initializing}"
  local i step tot=30
  printf "%s\n" "$label"
  for ((i=0;i<=tot;i++)); do
    printf "\r["
    for ((step=0; step<i; step++)); do printf "#"; done
    for ((step=i; step<tot; step++)); do printf "."; done
    printf "] %3d%%" $(( i*100/tot ))
    sleep "$(awk "BEGIN{printf \"%.2f\", $secs/$tot}")"
  done
  printf "\n"
}

disable_old_units(){
  c_c "Disabling older helper services/rules (safe if missing)..."
  local svcs=(unblock-bluetooth.service hci0-up.service csr-bt-activate.service csr-firmware.service)
  for s in "${svcs[@]}"; do
    systemctl stop "$s" 2>/dev/null || true
    systemctl disable "$s" 2>/dev/null || true
  done
  if [ -f "$OLD_UDEV_RULE" ]; then
    mkdir -p "$BACKUP_DIR"
    mv "$OLD_UDEV_RULE" "$BACKUP_DIR/$(basename "$OLD_UDEV_RULE").bak.$(date +%s)"
    udevadm control --reload-rules
    c_g "Backed up old udev rule to $BACKUP_DIR"
  fi
}

install_firmware(){
  local src="$1"
  if [ ! -f "$src" ]; then c_r "Firmware not found: $src"; return 1; fi
  install -m 0644 "$src" "$FIRMWARE_DST"
  c_g "Firmware installed -> $FIRMWARE_DST"
}

install_loader_script(){
  c_c "Installing loader script..."
  cat >/usr/local/bin/csr-fw-loader.sh <<'EOX'
#!/bin/bash
set -e
LOG=/var/log/csr-fw-loader.log
exec >>"$LOG" 2>&1
echo "=== csr-fw-loader starting: $(date) ==="
if command -v rfkill >/dev/null 2>&1; then
  rfkill unblock bluetooth || true
  rfkill unblock all || true
  echo "rfkill unblock done"
fi
modprobe -r btusb 2>/dev/null || true
sleep 0.5
modprobe btusb || true
echo "btusb reloaded"
TIMEOUT=25; i=0; BD=""
while [ $i -lt $TIMEOUT ]; do
  if hciconfig -a | grep -q '^hci0:'; then
    BD=$(hciconfig hci0 | awk '/BD Address/ {print $3}' || true)
    if [ -n "$BD" ] && [ "$BD" != "00:00:00:00:00:00" ]; then
      echo "found BD address: $BD"; break; fi
  fi; i=$((i+1)); sleep 1
done
if [ -n "$BD" ] && [ "$BD" != "00:00:00:00:00:00" ]; then
  hciconfig hci0 up || true; hciconfig hci0 reset || true; echo "hci0 up attempted"
else
  echo "Warning: BD not detected after reload (attempting bringup)"
  hciconfig hci0 up || true; hciconfig hci0 reset || true
fi
echo "=== csr-fw-loader finished: $(date) ==="
EOX
  chmod +x /usr/local/bin/csr-fw-loader.sh
}

install_watchdog_script(){
  c_c "Installing watchdog script..."
  cat >/usr/local/bin/csr-fw-watchdog.sh <<'EOX'
#!/bin/bash
LOG=/var/log/csr-fw-loader.log
exec >>"$LOG" 2>&1
echo "[WATCHDOG] $(date) --- running watchdog check"
if ! hciconfig | grep -q '^hci0:'; then
  echo "[WATCHDOG] hci0 missing, reloading btusb + firmware loader"
  /usr/local/bin/csr-fw-loader.sh; exit 0
fi
BD=$(hciconfig hci0 | awk '/BD Address/ {print $3}')
if [ "$BD" == "00:00:00:00:00:00" ] || [ -z "$BD" ]; then
  echo "[WATCHDOG] BD invalid ($BD), reloading firmware"
  /usr/local/bin/csr-fw-loader.sh; exit 0
fi
if rfkill list bluetooth 2>/dev/null | grep -q "Soft blocked: yes"; then
  echo "[WATCHDOG] rfkill soft-block, unblocking"
  rfkill unblock bluetooth; /usr/local/bin/csr-fw-loader.sh; exit 0
fi
STATE=$(hciconfig hci0 | grep -o "UP RUNNING")
if [ -z "$STATE" ]; then
  echo "[WATCHDOG] hci0 DOWN — bringing up"
  hciconfig hci0 up || true; hciconfig hci0 reset || true; exit 0
fi
echo "[WATCHDOG] All good (BD=$BD, state OK)"
EOX
  chmod +x /usr/local/bin/csr-fw-watchdog.sh
}

install_services(){
  c_c "Installing systemd units..."
  cat >/etc/systemd/system/csr-fw-loader.service <<'EOX'
[Unit]
Description=CSR Bluetooth firmware loader and bringup
Before=bluetooth.service
Wants=bluetooth.service
After=local-fs.target
[Service]
Type=oneshot
ExecStart=/usr/local/bin/csr-fw-loader.sh
RemainAfterExit=yes
[Install]
WantedBy=multi-user.target
EOX
  cat >/etc/systemd/system/csr-fw-watchdog.service <<'EOX'
[Unit]
Description=CSR Bluetooth watchdog auto-heal service
After=bluetooth.service
[Service]
Type=oneshot
ExecStart=/usr/local/bin/csr-fw-watchdog.sh
EOX
  cat >/etc/systemd/system/csr-fw-watchdog.timer <<'EOX'
[Unit]
Description=CSR Bluetooth watchdog timer
[Timer]
OnBootSec=15
OnUnitActiveSec=30
Persistent=true
[Install]
WantedBy=timers.target
EOX
  systemctl daemon-reload
  systemctl enable csr-fw-loader.service
  systemctl enable --now csr-fw-watchdog.timer
  systemctl start csr-fw-loader.service
}

install_sleep_hook(){
  c_c "Installing sleep/resume hook..."
  cat >/lib/systemd/system-sleep/csr-fw-resume <<'EOX'
#!/bin/bash
case "$1" in
  pre)  ;;
  post)
    echo "[SLEEP HOOK] System woke up: reloading CSR firmware" >> /var/log/csr-fw-loader.log
    /usr/local/bin/csr-fw-loader.sh
    ;;
esac
EOX
  chmod +x /lib/systemd/system-sleep/csr-fw-resume
}

create_block_rule(){
  c_c "Creating CSR-only udev block rule (prevents btusb binding)..."
  mkdir -p "$(dirname "$BLOCK_RULE")"
  cat >"$BLOCK_RULE" <<'EOX'
# Block only CSR8510 A10 (VID 0a12 PID 0001) from binding to btusb
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="0a12", ATTR{idProduct}=="0001", ATTR{driver_override}="none"
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="0a12", ATTR{idProduct}=="0001", RUN+="/bin/sh -c 'echo -n %k > /sys/bus/usb/drivers/btusb/unbind 2>/dev/null || true'"
EOX
  udevadm control --reload-rules
  udevadm trigger --subsystem-match=usb --attr-match=idVendor=0a12 --attr-match=idProduct=0001 || true
}

remove_block_rule(){
  if [ -f "$BLOCK_RULE" ]; then
    c_c "Removing CSR block rule..."
    rm -f "$BLOCK_RULE"
    udevadm control --reload-rules
  fi
}

list_csr_sysfs(){
  for d in /sys/bus/usb/devices/*; do
    [ -f "$d/idVendor" ] && [ -f "$d/idProduct" ] || continue
    [ "$(cat "$d/idVendor" 2>/dev/null)" = "0a12" ] || continue
    [ "$(cat "$d/idProduct" 2>/dev/null)" = "0001" ] || continue
    echo "$d"
  done
}

unbind_now_if_bound(){
  local changed=0
  for d in $(list_csr_sysfs); do
    local kname; kname="$(basename "$d")"
    if [ -e "/sys/bus/usb/drivers/btusb/$kname" ]; then
      echo -n "$kname" > /sys/bus/usb/drivers/btusb/unbind 2>/dev/null || true
      c_g "Unbound CSR device $kname from btusb."
      changed=1
    fi
  done
  return $changed
}

verify_block(){
  echo
  c_c "=== Verify CSR Block ==="
  if ! csr_present; then
    c_y "CSR dongle not detected by lsusb (0a12:0001). Plug it in to confirm block."
    return 0
  fi
  local any=0 bound=0
  for d in $(list_csr_sysfs); do
    any=1; local kname; kname="$(basename "$d")"
    if [ -e "/sys/bus/usb/drivers/btusb/$kname" ]; then
      c_r "Device $kname is still bound to btusb."; bound=1
    else
      c_g "Device $kname driver binding: none (OK)"
    fi
  done
  if [ "$any" -eq 0 ]; then
    c_y "CSR device not visible in sysfs yet; replug or reboot to enforce rules."
    return 0
  fi
  if [ "$bound" -eq 1 ]; then
    c_y "Attempting to unbind from btusb now..."; unbind_now_if_bound
    bound=0
    for d in $(list_csr_sysfs); do
      local kname; kname="$(basename "$d")"
      if [ -e "/sys/bus/usb/drivers/btusb/$kname" ]; then bound=1; fi
    done
    if [ "$bound" -eq 0 ]; then c_g "Successfully unbound. CSR is now blocked."; else c_r "Could not unbind all instances. Reboot is recommended."; fi
  else
    c_g "CSR is successfully blocked and will not create hci0."
  fi
  echo
}

state_print(){
  local state="$1"
  case "$state" in
    INSTALLED) printf "${CLR_GRN}STATE: %s${CLR_RST}\n\n" "$state" ;;
    BLOCKED)   printf "${CLR_RED}STATE: %s${CLR_RST}\n\n" "$state" ;;
    BROKEN|PARTIAL|STARTING) printf "${CLR_YLW}STATE: %s${CLR_RST}\n\n" "$state" ;;
    *)         printf "STATE: %s\n\n" "$state" ;;
  esac
}

detect_state(){
  local loader_en watchdog_en loader_act watchdog_act block fw hci hci_up
  loader_en="disabled"; svc_enabled csr-fw-loader.service && loader_en="enabled"
  watchdog_en="disabled"; svc_enabled csr-fw-watchdog.timer && watchdog_en="enabled"
  loader_act="inactive"; svc_active csr-fw-loader.service && loader_act="active"
  watchdog_act="inactive"; svc_active csr-fw-watchdog.timer && watchdog_act="active"
  block="absent"; [ -f "$BLOCK_RULE" ] && block="active"
  fw="missing"; [ -f "$FIRMWARE_DST" ] && fw="present"
  hci="absent"; hciconfig | grep -q '^hci0:' && hci="present"
  hci_up="down"; [ "$hci" = "present" ] && hciconfig | grep -q "UP RUNNING" && hci_up="up"

  if [ "$block" = "active" ] && [ "$fw" = "missing" ] && [ "$hci" != "present" ]; then echo "BLOCKED"; return; fi
  if [ "$fw" = "present" ] && [ "$loader_en" = "enabled" ] && [ "$watchdog_en" = "enabled" ] && [ "$hci_up" = "up" ]; then echo "INSTALLED"; return; fi
  if [ "$loader_en" = "disabled" ] && [ "$watchdog_en" = "disabled" ] && [ "$block" = "absent" ] && [ "$fw" = "missing" ]; then echo "PARTIAL"; return; fi
  echo "BROKEN"
}

show_status(){
  local state; state="$(detect_state)"; [ "$state" = "STARTING" ] && state="BROKEN"; state_print "$state"
  c_c "=== Firmware & Driver ==="
  if [ -f "$FIRMWARE_DST" ]; then echo "  Firmware:      present ($FIRMWARE_DST)"; else echo "  Firmware:      missing"; fi
  if [ -f "$BLOCK_RULE" ]; then echo "  CSR block:     ACTIVE ($BLOCK_RULE)"; else echo "  CSR block:     not present"; fi

  if csr_present; then
    if hciconfig | grep -q '^hci0:'; then echo "  Driver bind:   btusb (hci0 active)"
    else
      local bound="none"
      for d in /sys/bus/usb/drivers/btusb/*; do
        [[ "$d" =~ [0-9]+-[0-9]+ ]] || continue
        if [ -f "/sys/bus/usb/devices/$(basename "$d")/idVendor" ] && \
           [ "$(cat "/sys/bus/usb/devices/$(basename "$d")/idVendor" 2>/dev/null)" = "0a12" ] && \
           [ "$(cat "/sys/bus/usb/devices/$(basename "$d")/idProduct" 2>/dev/null)" = "0001" ]; then bound="btusb"; break; fi
      done
      echo "  Driver bind:   $bound"
    fi
  else
    echo "  Driver bind:   n/a (dongle not present)"
  fi

  if [ -f "$BLOCK_RULE" ] && [ "$SHOW_HCICONFIG_WHEN_BLOCKED" = "false" ]; then
    echo "  hci0:          hidden (blocked)"
  else
    if hciconfig | grep -q '^hci0:'; then
      if hciconfig | grep -q "UP RUNNING"; then local bd; bd="$(hciconfig hci0 | awk '/BD Address/ {print $3}')"; echo "  hci0:          UP (BD: $bd)"
      else echo "  hci0:          present (down)"; fi
    else echo "  hci0:          not present"; fi
  fi
  echo

  c_c "=== Services ==="
  svc_enabled csr-fw-loader.service && echo "  Loader:        enabled ($(systemctl is-active csr-fw-loader.service))" || echo "  Loader:        disabled"
  svc_enabled csr-fw-watchdog.timer && echo "  Watchdog:      enabled ($(systemctl is-active csr-fw-watchdog.timer))" || echo "  Watchdog:      disabled"
  [ -x /lib/systemd/system-sleep/csr-fw-resume ] && echo "  Sleep Hook:    installed" || echo "  Sleep Hook:    not installed"
  echo

  c_c "=== rfkill ==="
  rfkill list 2>/dev/null | sed 's/^/  /' || echo "  (rfkill not available)"
  echo

  c_c "=== Logs ==="
  if [ -f "$LOGFILE" ]; then
    if [ "$TRUNCATE_LOG_ON_UNINSTALL" = "true" ] && grep -q "=== LOG TRUNCATED ON UNINSTALL ===" "$LOGFILE" 2>/dev/null; then
      echo "  (logs were truncated during uninstall)"
    fi
    tail -n 30 "$LOGFILE" 2>/dev/null | sed 's/^/  /'
  else
    echo "  (no log file yet)"
  fi
  echo

  if [ -f "$BLOCK_RULE" ]; then verify_block; fi
}

bringup_now(){
  printf "${CLR_YLW}STATE: STARTING${CLR_RST}\n\n"
  progress_bar 2.5 "Initializing firmware..."
  /usr/local/bin/csr-fw-loader.sh >/dev/null 2>&1 || true
  local i; for i in {1..5}; do
    if hciconfig | grep -q '^hci0:' && hciconfig | grep -q 'UP RUNNING'; then break; fi
    sleep 0.6
  done
}

uninstall_everything(){
  c_c "Stopping/Disabling services..."
  systemctl stop csr-fw-loader.service 2>/dev/null || true
  systemctl stop csr-fw-watchdog.timer 2>/dev/null || true
  systemctl disable csr-fw-loader.service 2>/dev/null || true
  systemctl disable csr-fw-watchdog.timer 2>/dev/null || true
  systemctl daemon-reload

  c_c "Removing scripts/units/hooks..."
  rm -f /usr/local/bin/csr-fw-loader.sh /usr/local/bin/csr-fw-watchdog.sh
  rm -f /etc/systemd/system/csr-fw-loader.service /etc/systemd/system/csr-fw-watchdog.service /etc/systemd/system/csr-fw-watchdog.timer
  rm -f /lib/systemd/system-sleep/csr-fw-resume
  systemctl daemon-reload

  if [ -f "$FIRMWARE_DST" ]; then
    read -rp "Remove firmware file at $FIRMWARE_DST ? [y/N]: " rmfw
    if [[ "${rmfw:-N}" =~ ^[Yy]$ ]]; then rm -f "$FIRMWARE_DST"; c_g "Firmware removed."; else c_y "Keeping firmware file."; fi
  fi

  create_block_rule; sleep 0.3; unbind_now_if_bound

  if [ -f "$LOGFILE" ] && [ "$TRUNCATE_LOG_ON_UNINSTALL" = "true" ]; then
    : > "$LOGFILE"; echo "=== LOG TRUNCATED ON UNINSTALL === $(date)" >> "$LOGFILE"
  fi

  c_g "Uninstall complete. CSR device will no longer bind to btusb."
  verify_block

  if [ "$REBOOT_POLICY" = "ask" ]; then
    read -rp "Reboot now to fully enforce blocking? [y/N]: " rb
    if [[ "${rb:-N}" =~ ^[Yy]$ ]]; then reboot; fi
  fi
}

install_all(){
  need rfkill; need hciconfig || true; need systemctl
  disable_old_units
  remove_block_rule
  local fw_src="$DEFAULT_FIRMWARE_SRC"
  install_firmware "$fw_src" || { c_r "Firmware install failed."; exit 1; }
  install_loader_script
  install_watchdog_script
  install_services
  install_sleep_hook
  modprobe -r btusb 2>/dev/null || true; sleep 0.5; modprobe btusb || true
  bringup_now
  c_g "Install complete."
  show_status
}

menu(){
  while :; do
    echo
    c_c "CSR Bluetooth Firmware Manager"
    echo "1) Install CSR firmware auto-loader"
    echo "2) Uninstall EVERYTHING (remove scripts + disable CSR driver)"
    echo "3) Reinstall (uninstall + install)"
    echo "4) Show status"
    echo "5) Exit"
    read -rp "Select an option [1-5]: " ans
    case "${ans:-}" in
      1) install_all ;;
      2) uninstall_everything ;;
      3) uninstall_everything; install_all ;;
      4) show_status ;;
      5) exit 0 ;;
      *) c_y "Invalid choice."; ;;
    esac
  done
}
require_root
menu
# (END csr-fw-manager.sh)
